

<div id="wrapper">

    <!-- Sidebar -->
    <div id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <li>
                <a href="{{ url('admin/dashboard') }}">Dashboard</a>
            </li>
            <li>
                <a href="{{ url('admin/categories') }}">Categories</a>
            </li>
            <li>
                <a href="{{ url('admin/brands') }}">Brands</a>
            </li>
            <li>
                <a href="{{ url('admin/products') }}">Products</a>
            </li>
        </ul>
    </div>
